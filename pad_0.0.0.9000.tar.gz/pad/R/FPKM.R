FPKM <- function (counts, effective_lengths,log2=TRUE){
    x <- exp(log(counts) - log(effective_lengths) - log(sum(counts)) + log(1E9))
    if(log2)  return(log2(x)) else return(x)
}


