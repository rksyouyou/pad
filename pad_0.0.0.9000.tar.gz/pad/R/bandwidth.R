
cmp_cv <- function(x,y,J=10,h){ # multifold CV for bandwidth selection
    ## x: GC content
    ## y: FPKM value
    ## J: number of folds
    ## h: bandwidth

    N <- 100 # number of grid
    n <- length(x)
    cv <- 0

    ## to save computation, the raw x and y are used to generate initial value
    ## starting values are the same for all training sets
    sval <- best_of_nruns(x,y,2)

    ## construct training and testing sets
    folds <- sample(cut(seq(1,n),breaks=J,labels=FALSE),size=n)

    for(j in 1:J){
        pick <- which(folds==j)
        trainx <- x[pick]
        trainy <- y[pick]
        testx <- x[-pick]
        testy <- y[-pick]
        ## estimate
        res <- NULL
        while(is.null(res)){
            tryCatch({
                res <- em_nonp(trainx,trainy,h=h,N=N,sval$best.pi,sval$best.mu,sval$best.sig,maxit=2000,eps=0.001,verb=FALSE,earlyStop=TRUE) # em
            },error=function(e){})
        }
        ## interpolate
        p.pi <- stats::approx(trainx,res$f.pi[,1],testx,rule=2)$y
        p.m1 <- stats::approx(trainx,res$f.m[,1],testx,rule=2)$y
        p.m2 <- stats::approx(trainx,res$f.m[,2],testx,rule=2)$y
        p.sig1 <- stats::approx(trainx,res$f.sig[,1],testx,rule=2)$y
        p.sig2 <- stats::approx(trainx,res$f.sig[,2],testx,rule=2)$y
        w1 <- p.pi*stats::dnorm(testy,p.m1,p.sig1)
        w2 <- (1-p.pi)*stats::dnorm(testy,p.m2,p.sig2)
        estp1 <- w1/(w1+w2)
        esty <- p.m1*estp1 + p.m2*(1-estp1)
        cv <- cv + sum((esty - testy)^2)
    }
    return(cv)
}

find_bw <- function(x,y,J,hset){
    ## x,y,J: transferred to cmp_cv function
    ## hset: a considered set of h values
    nh <- length(hset)
    cvec <- rep(NA,nh)
    for(i in 1:nh) cvec[i] <- cmp_cv(x,y,J,hset[i])
    return(hset(which.max(cvec)))
}
