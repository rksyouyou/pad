
em_nonp<- function(x,y,h=0.1,N=100,s.pi,s.mu,s.sig,maxit=100,eps=0.01,kernel='epan',verb=TRUE,earlyStop=TRUE){

    ## x: GC content
    ## y: FPKM values
    ## h: bandwidth
    ## N: number of grids
    ## s.pi,s.mu,s.sig: N*2 starting values
    ## maxit: maximum number of iteration
    ## eps: convergence criterion, the iteration will stop when the distance of two adjacent local log likelihood values are smaller than eps.
    ## kernel: kernel function
    ## verb
    ## earlyStop: shall we stop iteration when the local log likelihood start to decrese.

    n <- length(x)
    xgrid <- seq(min(x),max(x),length=N)
    if(kernel == 'epan') kmat <- t(sapply(x, function(a) epan((xgrid - a)/h)/ h))
    if(kernel == 'gaussian') kmat <- t(sapply(x, function(a) gauss((xgrid - a)/h)/ h))
    iter <- 0
    lll <- sum(log(stats::dnorm(y,s.mu[,1],s.sig[,1])*s.pi[,1]+stats::dnorm(y,s.mu[,2],s.sig[,2])*s.pi[,2])*kmat)
    best.mu <- s.mu
    best.pi <- s.pi
    best.sig <- s.sig

    while(1){

        iter <- iter + 1
        ## E step
        r1 <- s.pi[,1]*stats::dnorm(y,s.mu[,1],s.sig[,1])
        r2 <- s.pi[,2]*stats::dnorm(y,s.mu[,2],s.sig[,2])
        rmat <- cbind(r1/(r1+r2),r2/(r1+r2))
        w1 <- rmat[,1]*kmat
        w2 <- rmat[,2]*kmat
        ## M step
        est.pi1 <- colSums(w1)/colSums(kmat)
        est.pi2 <- 1- est.pi1
        s.pi1 <- stats::approx(x=xgrid, y=est.pi1,xout=x,rule=2)$y
        s.pi2 <- stats::approx(x=xgrid, y=est.pi2,xout=x,rule=2)$y
        est.m1 <- colSums(w1*y)/colSums(w1)
        est.m2 <- colSums(w2*y)/colSums(w2)
        s.m1 <- stats::approx(x=xgrid, y=est.m1,xout=x,rule=2)$y
        s.m2 <- stats::approx(x=xgrid, y=est.m2,xout=x,rule=2)$y
        est.var1 <- colSums(w1*(y-s.m1)^2)/colSums(w1)
        est.var2 <- colSums(w2*(y-s.m2)^2)/colSums(w2)
        s.var1 <- stats::approx(x=xgrid, y=est.var1,xout=x,rule=2)$y
        s.var2 <- stats::approx(x=xgrid, y=est.var2,xout=x,rule=2)$y
        s.sig1 <- sqrt(s.var1)
        s.sig2 <- sqrt(s.var2)

        z1 <- min(s.sig1[s.sig1>0])/2
        z2 <- min(s.sig2[s.sig2>0])/2
        s.sig1[s.sig1==0] <- z1
        s.sig2[s.sig2==0] <- z2

        ## compute local log-likelihood function
        lll.new <- sum(log(stats::dnorm(y,s.m1,s.sig1)*s.pi1+stats::dnorm(y,s.m2,s.sig2)*s.pi2)*kmat)

        if(verb) cat('iter = ',iter,': ',lll.new,'\n')
        if(iter>maxit){
            if(verb) print('The maximum iteration number is reached!')
            convcode <- 1
            break
        }
        if(abs(lll[iter]-lll.new)<eps){
            if(verb) print('Convergence conditions are met!')
            convcode <- 0
            break
        }

        if(earlyStop&(lll.new-lll[iter]<0)){
            if(verb) print('The local likelihood start to decrease. Early Stop!')
            convcode <- 2
            break
        }

        lll <- c(lll,lll.new)
        s.pi <- cbind(s.pi1,s.pi2)
        s.mu <- cbind(s.m1,s.m2)
        s.sig <- cbind(s.sig1,s.sig2)

        best.pi <- s.pi
        best.mu <- s.mu
        best.sig <- s.sig


    }

    flag <- which.max(colMeans(best.mu))
    if(flag==1)
        out <- list(lll=lll,f.pi=best.pi[,c(2,1)],f.m=best.mu[,c(2,1)],f.sig=best.sig[,c(2,1)],convcode=convcode)
    else
        out <- list(lll=lll,f.pi=best.pi,f.m=best.mu,f.sig=best.sig,convcode=convcode)
    return(out)
}

