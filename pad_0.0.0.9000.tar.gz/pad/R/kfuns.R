epan <- function(x) ifelse(abs(x)<=1,0.75*(1-x^2),0) # Epanechnikov kernel
gauss <- function(x) 1/sqrt(2*pi)*exp(-1/2*x^2) # gassian kernel 
