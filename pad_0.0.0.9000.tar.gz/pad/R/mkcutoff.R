
mkcutoff <- function(eprop,emu,esd){
    ## eprop: N*2 proportion estimates
    ## emu: N*2 mean value estimates 
    ## esd: N*2 sd value estimates 
    nu <- esd[,2]/esd[,1]
    d1 <- nu^2-1
    x1 <- (emu[,2]*d1 - nu^2*(emu[,2]-emu[,1]) - sqrt(nu^2*(emu[,2]-emu[,1])^2 + 2*esd[,2]^2*d1*log(nu*eprop[,1]/eprop[,2])))/d1
    x2 <- (emu[,2]*d1 - nu^2*(emu[,2]-emu[,1]) + sqrt(nu^2*(emu[,2]-emu[,1])^2 + 2*esd[,2]^2*d1*log(nu*eprop[,1]/eprop[,2])))/d1
    flag <- ifelse(stats::dnorm(x1,emu[,1],esd[,1])> stats::dnorm(x2,emu[,1],esd[,1]),1,0)
    res <- flag*x1+(1-flag)*x2
    return(res)
}
