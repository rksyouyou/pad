
#' presence/absence status detection.
#'
#' @param countData raw RNA-Seq data matrix of non-negative expression counts with rows corresponding to
#'  measurements from a single gene and columns to  measurements from a single experimental unit.
#' @param gene_len  numeric vector containing gene length for each gene.
#' @param gc_content numeric vector containing GC content for each gene.
#' @param nruns a positive integer, assign the value of M in `best-of-M' method to generate intial values.
#' @param h vector of candidate bandwidths for nonparametric EM algorithm. When the length of vector is larger than 1, multiple cross validation is used for bandwidth selection, the resulting optimal bandwidth will be used in subsequent analysis.
#' @param kernel the kernel function to be used in nonparametric EM algorithm. Choice is {epan, gaussian}.
#' @param ngrid a positve integer, indicating the number of gridin nonparametric EM algorithm.
#' @param earlyStop a logical scalar, indicating whether to stop the iteration when local log-likelihood start to decrese before converge or reach the maximum number of iteration.
#' @param o_ival a small positive integer, indicating the order of polynomial regression in best-of-M method. The default value is set to be 2.
#' @param cv_fold a positive integer, indicating the number of fold of cross validation in bandwidth selection. It will be ignored when the length of h is 1. The default value is set to be 10.
#' @param maxit_ival a positive integer, the maximum number of iterations allowed if iterative fitting is necessary for nonparametric EM algorithm in best-of-M method. The default value is set to be 50.
#' @param maxit_em positive integer, the maximum number of iterations allowed if iterative fitting is necessary for nonparametric EM algorithm in parameter estimation. The default value is set to be 200.
#' @param eps small positive value, indicating the desired accuracy of parameter estimates. The iteration will stop if the distance between two adjacent logcal log-likelihood is smaller than eps.
#' @param verb a logical scalar, indicating whether intermediate messages should be printed.
#'
#'
#' @return
#' A list of length equal to the number of columns of countData. Each component contains following items.
#' \item{est.p}{Parameter estimates for mixing proportion from nonparametric EM algorithm for each gene.}
#' \item{est.m}{Parameter estimates for mean functions from nonparametric EM algorithm for each gene.}
#' \item{est.s}{Parameter estimates for variance functions from nonparametric EM algorithm for each gene.}
#' \item{cuts}{Estiamted cutoffs for each gene.}
#' \item{status}{Detect gene status, 1 and 0 denote \dQuote{on} and \dQuote{off} respectively.}
#'
#' @export
#' @examples
#' set.seed(500)
#' n <- 100
#' ## simulate gene length
#' gene_len <- rgamma(n,3,0.002)
#' ## simulate gc content
#' gc_content <- runif(n,0.1,0.9)
#' ## simulate counts data
#' counts <- round(exp(matrix(rnorm(2*n,1,2),ncol=2))) # simulate
#' out <- pad(counts,gene_len,gc_content,nruns=10,h=0.1,kernel='epan')
pad <-  function(countData,gene_len,gc_content,nruns,h,kernel='epan',ngrid=100,earlyStop=TRUE,o_ival=2,cv_fold=10,maxit_ival=50,maxit_em=200,eps=1e-3,verb=TRUE){

    ## normalization
    fpkm <- apply(countData,2,FPKM,gene_len)
    nc <- ncol(countData)
    nr <- nrow(countData)
    res <- list()

    for(i in 1:nc){ # apply nonpEM for each sample
        y0 <- countData[,i]
        keep <- which(y0>0) # only positive values are use for nonpEM
        y <- fpkm[keep,i]
        x <- gc_content[keep]
        ## initial values
        ival <- best_of_nruns(x,y,nruns = nruns,maxit=maxit_ival,o=o_ival)
        ## bandwidth selection
        if(length(h)>1) besth <- find_bw(x,y,J=cv_fold,h) else  besth <- h
        ## nonpEM
        out <- em_nonp(x,y,besth,ngrid,ival$best.pi,ival$best.m,ival$best.sig,maxit_em,eps,kernel,verb,earlyStop)
        cuts <- mkcutoff(out$f.pi,out$f.m,out$f.sig)
        out.cuts <- rep(NA,nr)
        out.status <- rep(0,nr)
        out.p <- out.m <- out.s <- matrix(NA,nr,2)
        out.cuts[keep] <- cuts
        out.status[keep] <- ifelse(y<cuts,0,1)
        out.p[keep,] <- out$f.pi
        out.m[keep,] <- out$f.m
        out.s[keep,] <- out$f.sig
        rownames(out.p) <- rownames(out.m) <- rownames(out.s) <- names(out.cuts) <- names(out.status) <- rownames(countData)
        res[[i]] <- list(est.p=out.p,est.m=out.m,est.s=out.s,cuts=out.cuts,status=out.status)
    }
    names(res) <- colnames(countData)
    return(res)
}




