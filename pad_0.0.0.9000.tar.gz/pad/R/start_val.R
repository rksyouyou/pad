
start_val_poly <- function(x,y,o = 5){
    ## x: GC content level
    ## y: FPKM value
    ## o: the highest order of polynomial matrix
    newx <- x
    n <- length(y)
    for(i in 2:o) newx <- cbind(newx,x^i)
    sfit <- mixtools::regmixEM(y, newx)
    start.pi <- matrix(sfit$lambda,nrow=n,ncol=2,byrow=TRUE)
    start.mu <- sfit$x%*%sfit$beta
    start.sig <- matrix(sfit$sigma,nrow=n,ncol=2,byrow=TRUE)
    print('Get initial values.')
    return(list(start.pi=start.pi,start.mu=start.mu,start.sig=start.sig))
}


best_of_nruns <- function(x,y,nruns,o=2,h=0.1,maxit){
    ## x: GC content level
    ## y: FPKM value
    ## o: input for start_val_poly
    ## h: bandwidth for nonparametric EM
    ## maxit: maximum number of iteration
    n  <- length(y)
    ## initialization
    best.lll <- -Inf
    xgrid <- seq(min(x),max(x),length=100)
    kmat <- t(sapply(x, function(a) epan((xgrid - a)/h)/ h))

    lll.tmp <- rep(NA,nruns)
    for(t in 1:nruns){
        sval1 <- start_val_poly(x,y,o)
        res1 <- em_nonp(x,y,h=h,N=100,sval1$start.pi,sval1$start.mu,sval1$start.sig,maxit=maxit,eps=0.001,verb=TRUE,earlyStop = FALSE)
        tmp.pi <- cbind(stats::approx(x,res1$f.pi[,1],xout=x,rule=2)$y,stats::approx(x,res1$f.pi[,2],xout=x,rule=2)$y)
        tmp.m <- cbind(stats::approx(x,res1$f.m[,1],xout=x,rule=2)$y,stats::approx(x,res1$f.m[,2],xout=x,rule=2)$y)
        tmp.sig <- cbind(stats::approx(x,res1$f.sig[,1],xout=x,rule=2)$y,stats::approx(x,res1$f.sig[,2],xout=x,rule=2)$y)
        lll.tmp[t] <- sum(log(stats::dnorm(y,tmp.m[,1],tmp.sig[,1])*tmp.pi[,1]+stats::dnorm(y,tmp.m[,2],tmp.sig[,2])*tmp.pi[,2])*kmat)
        if(lll.tmp[t]>best.lll){
            best.lll <- lll.tmp[t]
            best.pi <- tmp.pi
            best.m <- tmp.m
            best.sig <- tmp.sig
        }
    }
    return(list(best.pi=best.pi,best.mu=best.m,best.sig=best.sig))
}

